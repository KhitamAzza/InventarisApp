/* ════════════════════════════════════════════════════════════
seed.js — Seed initial categories & locations to Firestore
HOW TO EDIT: 
1. Modify the SEED_CATEGORIES or SEED_LOCATIONS objects below.
2. Click the "Seed Config" button in the Dev Tools panel.
3. If you made a mistake, use the "Clear Config" button to wipe 
   them from Firestore, fix the code, and seed again.
════════════════════════════════════════════════════════════ */
import { collection, getDocs, deleteDoc, doc, setDoc } 
from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

/* ── EDIT YOUR CATEGORIES HERE ────────────────────────────── 
   To add a new category, copy a block and change the key (e.g., "Printer").
   To add a new field to a category, add an object to the "schema" array.
   Types can be "text" or "number".
*/
const SEED_CATEGORIES = {
    PC: {
        label: "PC", order: 1,
        schema: [
            { key: "merk",      label: "Merk",      type: "text",   required: true },
            { key: "processor", label: "Processor", type: "text",   required: true },
            { key: "ram",       label: "RAM",       type: "text",   required: true },
            { key: "storage",   label: "Storage",   type: "text",   required: true },
            { key: "vga",       label: "VGA",       type: "text",   required: true }
        ]
    },
    Monitor: {
        label: "Monitor", order: 2,
        schema: [
            { key: "merk", label: "Merk",          type: "text",   required: true },
            { key: "size", label: "Ukuran (inch)", type: "number", required: true }
        ]
    },
    Furnitur: {
        label: "Furnitur", order: 3,
        schema: [{ key: "name", label: "Nama", type: "text", required: true }]
    },
    Elektronik: {
        label: "Elektronik", order: 4,
        schema: [{ key: "name", label: "Nama", type: "text", required: true }]
    }
    // Example of how to add a new one:
    // Printer: { label: "Printer", order: 5, schema: [{ key: "type", label: "Tipe", type: "text", required: true }] }
};

/* ── EDIT YOUR LOCATIONS HERE ─────────────────────────────── 
   Just add or remove objects from this array. 
   Keep the 'order' number sequential.
*/
const SEED_LOCATIONS = [
    { id: "Lab DKV",  name: "Lab DKV",  order: 1 }
];

/* ── Seed Button Logic ────────────────────────────────────── */
$("seed-btn").addEventListener("click", async () => {
    if (!confirm("Tulis konfigurasi kategori & lokasi ke Firestore? (aman diulang)")) return;
    $("seed-btn").disabled = true;
    try {
        for (const [id, data] of Object.entries(SEED_CATEGORIES)) {
            await setDoc(doc(db, "categories", id), data);
        }
        for (const loc of SEED_LOCATIONS) {
            await setDoc(doc(db, "locations", loc.id), { name: loc.name, order: loc.order });
        }
        toast("Config seeded ✓");
        await Promise.all([loadCategories(), loadLocations()]);
    } catch (e) {
        console.error(e);
        toast("Seed failed: " + e.message, "bad");
    } finally {
        $("seed-btn").disabled = false;
    }
});

/* ── NEW: Clear / Delete Config (If you made a mistake) ───── */
// You can trigger this by adding a button in your HTML, or running it in the console.
window.clearAllConfig = async function() {
    if (!confirm("PERINGATAN: Ini akan menghapus SEMUA kategori dan lokasi dari database. Lanjutkan?")) return;
    
    try {
        // Delete Categories
        const catSnap = await getDocs(collection(db, "categories"));
        for (const d of catSnap.docs) {
            await deleteDoc(d.ref);
        }
        
        // Delete Locations
        const locSnap = await getDocs(collection(db, "locations"));
        for (const d of locSnap.docs) {
            await deleteDoc(d.ref);
        }
        
        toast("Semua config dihapus. Silakan seed ulang.");
        await Promise.all([loadCategories(), loadLocations()]);
    } catch (e) {
        toast("Gagal clear config: " + e.message, "bad");
    }
};

// Optional: Auto-wire a clear button if you add it to your HTML dev panel
const clearBtn = $("clear-config-btn");
if(clearBtn) {
    clearBtn.addEventListener("click", clearAllConfig);
}