/* ════════════════════════════════════════════════════════════
inventory.js — Add new items, dynamic schema, and live list
Relies on: core.js (must be loaded first)
════════════════════════════════════════════════════════════ */
import { runTransaction, doc, setDoc, deleteDoc, collection, onSnapshot } 
from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

/* ── Generate Sequential ID ───────────────────────────────── */
async function generateItemId() {
    const ref = doc(db, "meta", "counters");
    const next = await runTransaction(db, async (tx) => {
        const snap = await tx.get(ref);
        const last = snap.exists() ? (snap.data().lastInvNumber || 0) : 0;
        const n = last + 1;
        tx.set(ref, { lastInvNumber: n }, { merge: true });
        return n;
    });
    return `INV.KD${String(next).padStart(4, "0")}.${yymmdd()}`;
}

window.updateIdPreview = async function() {
    try {
        const snap = await getDoc(doc(db, "meta", "counters")); // Note: need to import getDoc if used here, or just rely on the transaction. 
        // Actually, let's keep it simple and just use the local state or fetch it.
        // For simplicity, we'll just fetch it:
        const { getDoc } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js");
        const snap2 = await getDoc(doc(db, "meta", "counters"));
        const last = snap2.exists() ? (snap2.data().lastInvNumber || 0) : 0;
        $("id-preview").textContent = `ID berikutnya ≈ INV.KD${String(last + 1).padStart(4, "0")}.${yymmdd()}`;
    } catch {}
}

/* ── Dynamic Form (Per Category) ──────────────────────────── */
$("cat-select").addEventListener("change", () => {
    const id  = $("cat-select").value;
    const box = $("dynamic-fields");
    box.innerHTML = "";
    if (!id || !CATEGORIES[id]) return;
    
    CATEGORIES[id].schema.forEach((f) => {
        const wrap = document.createElement("label");
        wrap.className = "field";
        wrap.innerHTML = `<span class="lbl">${escapeHtml(f.label)}${f.required ? ' <span class="req">*</span>' : ""}</span> 
                          <input data-key="${escapeHtml(f.key)}" type="${f.type || "text"}" ${f.required ? "required" : ""} ${f.type === "number" ? 'step="any"' : ""} />`;
        box.appendChild(wrap);
    });
});

/* ── Add Item Submission ──────────────────────────────────── */
$("add-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const catId  = $("cat-select").value;
    const lokasi = $("lokasi-select").value;
    
    if (!catId || !CATEGORIES[catId]) return toast("Pilih kategori dulu", "bad");
    if (!lokasi) return toast("Pilih lokasi dulu", "bad");

    const inputs = $("dynamic-fields").querySelectorAll("input[data-key]");
    const fields = {};
    for (const inp of inputs) {
        const v = inp.value.trim();
        if (inp.required && !v) return toast(`"${inp.dataset.key}" wajib diisi`, "bad");
        if (v) fields[inp.dataset.key] = inp.type === "number" ? Number(v) : v;
    }

    $("submit-btn").disabled = true;
    try {
        const itemId = await generateItemId();
        await setDoc(doc(db, "items", itemId), {
            category: catId, lokasi, addedAt: todayISO(), fields
        });
        toast(`Tersimpan: ${itemId} ✓`);
        $("add-form").reset();
        $("dynamic-fields").innerHTML = "";
        $("id-preview").textContent = "";
        updateIdPreview();
    } catch (err) {
        console.error(err);
        toast("Gagal menyimpan: " + err.message, "bad");
    } finally {
        $("submit-btn").disabled = false;
    }
});

/* ── Live Items List ──────────────────────────────────────── */
window.subscribeItems = function() {
    onSnapshot(collection(db, "items"), (snap) => {
        ALL_ITEMS = [];
        snap.forEach((d) => ALL_ITEMS.push({ id: d.id, ...d.data() }));
        ALL_ITEMS.sort((a, b) => 
            (b.addedAt || "").localeCompare(a.addedAt || "") || b.id.localeCompare(a.id)
        );
        renderItems();
    }, (err) => {
        console.error(err);
        toast("Gagal memuat daftar: " + err.message, "bad");
    });
};

["filter-text", "filter-lokasi"].forEach((id) => {
    const el = $(id);
    if(el) el.addEventListener("input", renderItems);
});

function applyFilters() {
    const q  = $("filter-text").value.trim().toLowerCase();
    const lk = $("filter-lokasi").value.trim();
    return ALL_ITEMS.filter((it) => {
        if (lk && (it.lokasi || "") !== lk) return false;
        if (!q) return true;
        const hay = [
            it.id, it.category, it.lokasi, it.addedAt,
            ...Object.entries(it.fields || {}).flat()
        ].join(" ").toLowerCase();
        return hay.includes(q);
    });
}

function renderItems() {
    const rows = applyFilters();
    const tbody = $("items-tbody");
    const cards = $("items-cards");
    
    if (!tbody || !cards) return;

    if (rows.length === 0) {
        const emptyMsg = ALL_ITEMS.length === 0 ? "Belum ada item." : "Tidak ada yang cocok.";
        tbody.innerHTML = `<tr><td colspan="6" class="muted" style="padding:16px">${emptyMsg}</td></tr>`;
        cards.innerHTML = `<div class="muted" style="padding:16px">${emptyMsg}</div>`;
        return;
    }

    /* Desktop Table */
    tbody.innerHTML = rows.map((it) => {
        const specs = Object.entries(it.fields || {})
            .map(([k, v]) => `<div><span class="k">${escapeHtml(k)}:</span> ${escapeHtml(v)}</div>`)
            .join("");
        return `<tr>
            <td><code>${escapeHtml(it.id)}</code></td>
            <td>${escapeHtml(it.category)}</td>
            <td>${escapeHtml(it.lokasi)}</td>
            <td>${escapeHtml(it.addedAt || "")}</td>
            <td class="specs">${specs}</td>
            <td><button class="btn danger" data-del="${escapeHtml(it.id)}" title="Hapus">✕</button></td>
        </tr>`;
    }).join("");

    /* Mobile Cards */
    cards.innerHTML = rows.map((it) => {
        const specs = Object.entries(it.fields || {})
            .map(([k, v]) => `<div><span class="k">${escapeHtml(k)}:</span> ${escapeHtml(v)}</div>`)
            .join("");
        return `<div class="item-card">
            <div class="item-head">
                <div>
                    <div class="item-id">${escapeHtml(it.id)}</div>
                    <div class="item-meta">${escapeHtml(it.category)} · ${escapeHtml(it.lokasi)} · ${escapeHtml(it.addedAt || "")}</div>
                </div>
                <button class="btn danger" data-del="${escapeHtml(it.id)}" title="Hapus">✕</button>
            </div>
            <div class="item-specs">${specs}</div>
        </div>`;
    }).join("");
}

/* ── Delete Item Listener ─────────────────────────────────── */
document.body.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-del]");
    if (!btn) return;
    const id = btn.dataset.del;
    if (!confirm(`Hapus ${id}?`)) return;
    try {
        await deleteDoc(doc(db, "items", id));
        toast(`Terhapus: ${id}`);
    } catch (err) {
        toast("Gagal hapus: " + err.message, "bad");
    }
});