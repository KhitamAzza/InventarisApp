/* ════════════════════════════════════════════════════════════
   nav.js — bottom nav / sidebar, description card, overflow drawer,
   greeting text. Presentation only: no Firebase or business logic
   lives here. Navigation itself (showScreen) still comes from
   core.js — this file just reacts to whichever screen becomes
   active and keeps the chrome (nav highlight, description, drawer)
   in sync.
   ════════════════════════════════════════════════════════════ */

const NAV_META = {
    menu:        { title: "Beranda ",              desc: "Ringkasan maintenance & aktivitas hari ini. " },
    scan:        { title: "Scan QR ",               desc: "Pindai kode QR untuk memeriksa item ini. " },
    problem:     { title: "Inventaris Bermasalah ", desc: "Item yang dilaporkan rusak atau perlu ditindaklanjuti. " },
    maintenance: { title: "Mode Maintenance ",      desc: "Mulai sesi pemeriksaan & pencatatan maintenance. " },
    add:         { title: "Tambah Inventaris ",     desc: "Tambahkan item baru ke database. " },
    list:        { title: "Daftar Inventaris ",     desc: "Telusuri & filter seluruh item yang tersimpan. " },
    print:       { title: "Cetak Label QR ",        desc: "Cetak label QR untuk item inventaris via Bluetooth. " },
};

const $ = (id) => document.getElementById(id);
const drawer         = $("drawer");
const drawerBackdrop = $("drawer-backdrop");

function updateChrome(name) {
  document.body.classList.toggle("chrome-hidden", name === "splash");

  document.querySelectorAll(".bottom-nav-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.nav === name);
  });

  const meta = NAV_META[name];
  if (meta) {
    $("desc-title").textContent = meta.title;
    $("desc-sub").textContent = meta.desc;
  }
}

/* re-run whenever core.js swaps the active screen, whether that
   came from a click or the splash → menu timeout in boot() */
document.querySelectorAll(".screen").forEach((screen) => {
  new MutationObserver(() => {
    if (screen.classList.contains("active")) {
      updateChrome(screen.id.replace("screen-", ""));
    }
  }).observe(screen, { attributes: true, attributeFilter: ["class"] });
});

/* overflow drawer open/close */
function openDrawer()  { drawer.classList.add("open");    drawerBackdrop.classList.add("show"); }
function closeDrawer() { drawer.classList.remove("open"); drawerBackdrop.classList.remove("show"); }

document.body.addEventListener("click", (e) => {
  if (e.target.closest("[data-drawer-open]"))  openDrawer();
  if (e.target.closest("[data-drawer-close]")) closeDrawer();
  if (e.target === drawerBackdrop)             closeDrawer();
  if (e.target.closest(".drawer [data-nav]"))  closeDrawer(); /* close after picking an item */
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeDrawer();
});

/* time-based greeting on Beranda (presentational only, no user data) */
function greetingText() {
  const h = new Date().getHours();
  if (h < 11) return "Selamat pagi,";
  if (h < 15) return "Selamat siang,";
  if (h < 19) return "Selamat sore,";
  return "Selamat malam,";
}
const greetEl = $("greeting-eyebrow");
if (greetEl) greetEl.textContent = greetingText();

/* initial state before splash hands off to the menu screen */
updateChrome("splash");