/* ════════════════════════════════════════════════════════════
core.js — Firebase init, global helpers, router, and config loaders
MUST RUN FIRST.
════════════════════════════════════════════════════════════ */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
    getFirestore, collection, doc, getDocs, deleteDoc,
    query, orderBy
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

/* ── Firebase Init ────────────────────────────────────────── */
const firebaseConfig = {
    apiKey: "AIzaSyAoW-WTDueAHLYNfPAuDcf6m1U4pSPie-o",
    authDomain: "inventorazz.firebaseapp.com",
    databaseURL: "https://inventorazz-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "inventorazz",
    storageBucket: "inventorazz.firebasestorage.app",
    messagingSenderId: "754984170276",
    appId: "1:754984170276:web:ddd7f9f7880e6101a539b1"
};
const app = initializeApp(firebaseConfig);
window.db = getFirestore(app);


// Attach to window so other modular files can access it
window.db = getFirestore(app);
window.CATEGORIES = {};
window.ALL_ITEMS = [];

/* ── Global Helpers ───────────────────────────────────────── */
window.$ = (id) => document.getElementById(id);

window.toast = function(msg, kind = "ok") {
    const el = $("toast");
    el.textContent = msg;
    el.className = "toast show " + kind;
    clearTimeout(el._t);
    el._t = setTimeout(() => (el.className = "toast"), 2400);
};

window.todayISO = function() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

window.yymmdd = function() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return String(d.getFullYear()).slice(-2) + p(d.getMonth() + 1) + p(d.getDate());
};

window.escapeHtml = function(s) {
    return String(s ?? " ").replace(/[&<>"']/g, (c) => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
};

/* ── Router ───────────────────────────────────────────────── */
const SCREENS = ["splash", "menu", "add", "list", "scan", "problem", "maintenance", "print"];
window.showScreen = function(name) {
    SCREENS.forEach((s) => {
        const el = $("screen-" + s);
        if(el) el.classList.toggle("active", s === name);
    });
    window.scrollTo(0, 0);
};

document.body.addEventListener("click", (e) => {
    const nav = e.target.closest("[data-nav]");
    if (nav) showScreen(nav.dataset.nav);
});

/* ── Dev Tools Toggle ─────────────────────────────────────── */
const devToggle = $("dev-toggle");
const devPanel  = $("dev-panel");
if(devToggle && devPanel) {
    devToggle.addEventListener("click", () => {
        devPanel.hidden = !devPanel.hidden;
        devToggle.classList.toggle("active", !devPanel.hidden);
    });
}

/* ── Config Loaders ───────────────────────────────────────── */
async function loadCategories() {
    const snap = await getDocs(query(collection(db, "categories"), orderBy("order")));
    CATEGORIES = {};
    const sel = $("cat-select");
    sel.innerHTML = '<option value="">— pilih kategori —</option>';
    if (snap.empty) {
        sel.innerHTML += '<option value="" disabled>(belum ada — klik Seed Config)</option>';
        return;
    }
    snap.forEach((d) => {
        CATEGORIES[d.id] = d.data();
        const o = document.createElement("option");
        o.value = d.id; o.textContent = d.data().label || d.id;
        sel.appendChild(o);
    });
}

async function loadLocations() {
    const snap = await getDocs(query(collection(db, "locations"), orderBy("order")));
    const addSel = $("lokasi-select");
    const filSel = $("filter-lokasi");
    addSel.innerHTML = '<option value="">— pilih lokasi —</option>';
    filSel.innerHTML = '<option value="">Semua lokasi</option>';
    if (snap.empty) {
        addSel.innerHTML += '<option value="" disabled>(belum ada — klik Seed Config)</option>';
        return;
    }
    snap.forEach((d) => {
        const name = d.data().name || d.id;
        addSel.appendChild(new Option(name, name));
        filSel.appendChild(new Option(name, name));
    });
}

/* ── NEW: Delete Identifiers (Categories & Locations) ─────── */
window.deleteCategory = async function(id) {
    if (!confirm(`Hapus kategori "${id}"? Item dengan kategori ini tidak akan terhapus, tapi dropdown akan hilang.`)) return;
    try {
        await deleteDoc(doc(db, "categories", id));
        toast(`Kategori ${id} dihapus`);
        await loadCategories();
    } catch (e) { toast("Gagal hapus kategori: " + e.message, "bad"); }
};

window.deleteLocation = async function(id) {
    if (!confirm(`Hapus lokasi "${id}"?`)) return;
    try {
        await deleteDoc(doc(db, "locations", id));
        toast(`Lokasi ${id} dihapus`);
        await loadLocations();
    } catch (e) { toast("Gagal hapus lokasi: " + e.message, "bad"); }
};

/* ── Boot Sequence ────────────────────────────────────────── */
(async function boot() {
    const startedAt = Date.now();
    try {
        await Promise.all([loadCategories(), loadLocations()]);
        // updateIdPreview is in inventory.js, check if it exists before calling
        if(window.updateIdPreview) window.updateIdPreview(); 
    } catch (e) {
        console.error(e);
        toast("Init error: " + e.message, "bad");
    }
    
    // subscribeItems is in inventory.js
    if(window.subscribeItems) window.subscribeItems();

    const MIN_SPLASH = 1400;
    const wait = Math.max(0, MIN_SPLASH - (Date.now() - startedAt));
    setTimeout(() => showScreen("menu"), wait);
})();